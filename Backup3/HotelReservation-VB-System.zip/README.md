# Hotel Reservation System VB.NET

A minimalist beige and brown hotel reservation prototype built for Microsoft Visual Studio using Visual Basic Windows Forms and a local SQLite database.

## Features

- Room booking with availability checks
- Room type, capacity, amenity, and availability status display
- Guest information capture
- Add-ons/reserved amenities
- Payment record creation
- Receipt generation and printable receipt page
- Reservation history
- Local email and guest alert notification queue
- SQLite database created locally as `hotel_reservation.db` beside the executable

## Run In Visual Studio

1. Open `HotelReservation.sln` or `HotelReservation.vbproj` in Microsoft Visual Studio.
2. Let Visual Studio restore NuGet packages.
3. Press `F5` to run the VB.NET Windows Forms app.

The local database is created automatically the first time the app runs.
