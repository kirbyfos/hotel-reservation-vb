Imports System
Imports System.Collections.Generic
Imports System.Globalization
Imports System.Linq
Imports Microsoft.Data.Sqlite

Namespace HotelReservation
    Public Class HotelRepository
        Private ReadOnly _connectionString As String

        Public Sub New(databasePath As String)
            _connectionString = $"Data Source={databasePath}"
        End Sub

        Public Sub Initialize()
            Using connection = CreateConnection()
                connection.Open()
                Execute(connection, GetSchemaSql())
                SeedRooms(connection)
                SeedAddOns(connection)
            End Using
        End Sub

        Public Function GetRooms(Optional checkIn As Date? = Nothing, Optional checkOut As Date? = Nothing) As List(Of RoomInfo)
            Dim hasDates = checkIn.HasValue AndAlso checkOut.HasValue AndAlso checkOut.Value.Date > checkIn.Value.Date
            Dim rooms As New List(Of RoomInfo)()

            Using connection = CreateConnection()
                connection.Open()
                Using command = connection.CreateCommand()
                    command.CommandText =
                        "SELECT r.Id, r.RoomNumber, r.Type, r.Capacity, r.Rate, r.Amenities, " &
                        "CASE WHEN r.Status <> 'Available' THEN r.Status " &
                        "WHEN @HasDates = 1 AND EXISTS (" &
                        "SELECT 1 FROM Reservations res WHERE res.RoomId = r.Id " &
                        "AND res.Status IN ('Reserved', 'Checked In') " &
                        "AND date(res.CheckIn) < date(@CheckOut) AND date(res.CheckOut) > date(@CheckIn)) " &
                        "THEN 'Reserved' ELSE r.Status END AS AvailabilityStatus, " &
                        "CASE WHEN r.Status <> 'Available' THEN 0 " &
                        "WHEN @HasDates = 1 AND EXISTS (" &
                        "SELECT 1 FROM Reservations res WHERE res.RoomId = r.Id " &
                        "AND res.Status IN ('Reserved', 'Checked In') " &
                        "AND date(res.CheckIn) < date(@CheckOut) AND date(res.CheckOut) > date(@CheckIn)) " &
                        "THEN 0 ELSE 1 END AS IsAvailable " &
                        "FROM Rooms r ORDER BY r.Type, r.Rate;"
                    command.Parameters.AddWithValue("@HasDates", If(hasDates, 1, 0))
                    command.Parameters.AddWithValue("@CheckIn", If(hasDates, ToDate(checkIn.Value), ""))
                    command.Parameters.AddWithValue("@CheckOut", If(hasDates, ToDate(checkOut.Value), ""))

                    Using reader = command.ExecuteReader()
                        While reader.Read()
                            rooms.Add(New RoomInfo With {
                                .Id = reader.GetInt32(0),
                                .RoomNumber = reader.GetString(1),
                                .RoomType = reader.GetString(2),
                                .Capacity = reader.GetInt32(3),
                                .Rate = ToMoney(reader.GetDouble(4)),
                                .Amenities = reader.GetString(5),
                                .Status = reader.GetString(6),
                                .IsAvailable = reader.GetInt32(7) = 1
                            })
                        End While
                    End Using
                End Using
            End Using

            Return rooms
        End Function

        Public Function GetAddOns() As List(Of AddOnInfo)
            Dim addOns As New List(Of AddOnInfo)()

            Using connection = CreateConnection()
                connection.Open()
                Using command = connection.CreateCommand()
                    command.CommandText = "SELECT Id, Name, Description, Price FROM AddOns ORDER BY Name;"

                    Using reader = command.ExecuteReader()
                        While reader.Read()
                            addOns.Add(New AddOnInfo With {
                                .Id = reader.GetInt32(0),
                                .Name = reader.GetString(1),
                                .Description = reader.GetString(2),
                                .Price = ToMoney(reader.GetDouble(3))
                            })
                        End While
                    End Using
                End Using
            End Using

            Return addOns
        End Function

        Public Function CreateReservation(request As ReservationInput) As ReceiptInfo
            ValidateReservation(request)

            Dim confirmationCode As String
            Using connection = CreateConnection()
                connection.Open()
                Using transaction = connection.BeginTransaction()
                    Dim room = GetRoomForBooking(connection, transaction, request.RoomId)
                    If room Is Nothing Then
                        Throw New ArgumentException("Please select a valid room.")
                    End If

                    If room.Capacity < request.Guests Then
                        Throw New ArgumentException($"Room {room.RoomNumber} can only fit {room.Capacity} guest(s).")
                    End If

                    If Not IsRoomAvailable(connection, transaction, request.RoomId, request.CheckIn, request.CheckOut) Then
                        Throw New InvalidOperationException("This room is already reserved for the selected dates.")
                    End If

                    Dim selectedAddOns = GetSelectedAddOns(connection, transaction, request.AddOns)
                    Dim nights = Math.Max(1, CInt((request.CheckOut.Date - request.CheckIn.Date).TotalDays))
                    Dim roomSubtotal = nights * room.Rate
                    Dim addOnSubtotal = selectedAddOns.Sum(Function(item) item.Price * item.Quantity)
                    Dim total = roomSubtotal + addOnSubtotal
                    Dim now = DateTime.UtcNow
                    confirmationCode = GenerateConfirmationCode(connection, transaction)

                    Dim guestId = InsertScalar(connection, transaction,
                        "INSERT INTO Guests (FullName, Email, Phone, Address, CreatedAt) " &
                        "VALUES (@FullName, @Email, @Phone, @Address, @CreatedAt) RETURNING Id;",
                        ("@FullName", request.GuestName.Trim()),
                        ("@Email", request.Email.Trim()),
                        ("@Phone", request.Phone.Trim()),
                        ("@Address", If(String.IsNullOrWhiteSpace(request.Address), "", request.Address.Trim())),
                        ("@CreatedAt", ToDateTime(now)))

                    Dim notesValue As Object = If(String.IsNullOrWhiteSpace(request.Notes), CType(DBNull.Value, Object), request.Notes.Trim())
                    Dim reservationId = InsertScalar(connection, transaction,
                        "INSERT INTO Reservations (ConfirmationCode, RoomId, GuestId, CheckIn, CheckOut, Guests, Status, Notes, CreatedAt) " &
                        "VALUES (@ConfirmationCode, @RoomId, @GuestId, @CheckIn, @CheckOut, @Guests, 'Reserved', @Notes, @CreatedAt) RETURNING Id;",
                        ("@ConfirmationCode", confirmationCode),
                        ("@RoomId", request.RoomId),
                        ("@GuestId", guestId),
                        ("@CheckIn", ToDate(request.CheckIn)),
                        ("@CheckOut", ToDate(request.CheckOut)),
                        ("@Guests", request.Guests),
                        ("@Notes", notesValue),
                        ("@CreatedAt", ToDateTime(now)))

                    For Each addOn In selectedAddOns
                        Execute(connection, transaction,
                            "INSERT INTO ReservationAddOns (ReservationId, AddOnId, Quantity) VALUES (@ReservationId, @AddOnId, @Quantity);",
                            ("@ReservationId", reservationId),
                            ("@AddOnId", addOn.Id),
                            ("@Quantity", addOn.Quantity))
                    Next

                    Execute(connection, transaction,
                        "INSERT INTO Payments (ReservationId, Method, Amount, Status, PaidAt, Reference) " &
                        "VALUES (@ReservationId, @Method, @Amount, 'Paid', @PaidAt, @Reference);",
                        ("@ReservationId", reservationId),
                        ("@Method", request.PaymentMethod.Trim()),
                        ("@Amount", total),
                        ("@PaidAt", ToDateTime(now)),
                        ("@Reference", BuildPaymentReference(request.PaymentReference)))

                    QueueNotification(connection, transaction, reservationId, "Email", request.Email.Trim(),
                        "Hotel reservation confirmed",
                        $"Hello {request.GuestName.Trim()}, your reservation {confirmationCode} is confirmed for room {room.RoomNumber}.",
                        now)

                    QueueNotification(connection, transaction, reservationId, "Alert", request.Phone.Trim(),
                        "Arrival reminder",
                        $"Reminder: check-in starts on {request.CheckIn:MMM dd, yyyy}. Please bring a valid ID.",
                        now)

                    transaction.Commit()
                End Using
            End Using

            Dim receipt = GetReceipt(confirmationCode)
            If receipt Is Nothing Then
                Throw New InvalidOperationException("The reservation was saved, but the receipt could not be loaded.")
            End If

            Return receipt
        End Function

        Public Function GetReceipt(confirmationCode As String) As ReceiptInfo
            Using connection = CreateConnection()
                connection.Open()
                Using command = connection.CreateCommand()
                    command.CommandText =
                        "SELECT res.ConfirmationCode, g.FullName, g.Email, g.Phone, r.RoomNumber, r.Type, r.Amenities, " &
                        "res.CheckIn, res.CheckOut, res.Guests, res.Status, r.Rate, p.Method, p.Status, p.Reference, p.Amount, res.CreatedAt " &
                        "FROM Reservations res " &
                        "INNER JOIN Guests g ON g.Id = res.GuestId " &
                        "INNER JOIN Rooms r ON r.Id = res.RoomId " &
                        "INNER JOIN Payments p ON p.ReservationId = res.Id " &
                        "WHERE res.ConfirmationCode = @ConfirmationCode;"
                    command.Parameters.AddWithValue("@ConfirmationCode", confirmationCode)

                    Using reader = command.ExecuteReader()
                        If Not reader.Read() Then
                            Return Nothing
                        End If

                        Dim checkIn = ParseDate(reader.GetString(7))
                        Dim checkOut = ParseDate(reader.GetString(8))
                        Dim nights = Math.Max(1, CInt((checkOut.Date - checkIn.Date).TotalDays))
                        Dim rate = ToMoney(reader.GetDouble(11))
                        Dim addOnLines = GetReceiptAddOns(confirmationCode)
                        Dim addOnSubtotal = addOnLines.Sum(Function(item) item.Total)

                        Return New ReceiptInfo With {
                            .ConfirmationCode = reader.GetString(0),
                            .GuestName = reader.GetString(1),
                            .GuestEmail = reader.GetString(2),
                            .GuestPhone = reader.GetString(3),
                            .RoomNumber = reader.GetString(4),
                            .RoomType = reader.GetString(5),
                            .Amenities = reader.GetString(6),
                            .CheckIn = checkIn,
                            .CheckOut = checkOut,
                            .Nights = nights,
                            .Guests = reader.GetInt32(9),
                            .ReservationStatus = reader.GetString(10),
                            .RoomSubtotal = nights * rate,
                            .AddOns = addOnLines,
                            .AddOnSubtotal = addOnSubtotal,
                            .Total = ToMoney(reader.GetDouble(15)),
                            .PaymentMethod = reader.GetString(12),
                            .PaymentStatus = reader.GetString(13),
                            .PaymentReference = reader.GetString(14),
                            .CreatedAt = ParseDateTime(reader.GetString(16))
                        }
                    End Using
                End Using
            End Using
        End Function

        Public Function GetReservationHistory() As List(Of ReservationHistoryInfo)
            Dim history As New List(Of ReservationHistoryInfo)()

            Using connection = CreateConnection()
                connection.Open()
                Using command = connection.CreateCommand()
                    command.CommandText =
                        "SELECT res.ConfirmationCode, g.FullName, r.RoomNumber, r.Type, res.CheckIn, res.CheckOut, " &
                        "res.Guests, res.Status, p.Amount, res.CreatedAt " &
                        "FROM Reservations res " &
                        "INNER JOIN Guests g ON g.Id = res.GuestId " &
                        "INNER JOIN Rooms r ON r.Id = res.RoomId " &
                        "INNER JOIN Payments p ON p.ReservationId = res.Id " &
                        "ORDER BY datetime(res.CreatedAt) DESC;"

                    Using reader = command.ExecuteReader()
                        While reader.Read()
                            history.Add(New ReservationHistoryInfo With {
                                .ConfirmationCode = reader.GetString(0),
                                .GuestName = reader.GetString(1),
                                .RoomNumber = reader.GetString(2),
                                .RoomType = reader.GetString(3),
                                .CheckIn = ParseDate(reader.GetString(4)),
                                .CheckOut = ParseDate(reader.GetString(5)),
                                .Guests = reader.GetInt32(6),
                                .Status = reader.GetString(7),
                                .Total = ToMoney(reader.GetDouble(8)),
                                .CreatedAt = ParseDateTime(reader.GetString(9))
                            })
                        End While
                    End Using
                End Using
            End Using

            Return history
        End Function

        Public Function GetNotifications() As List(Of NotificationInfo)
            Dim notifications As New List(Of NotificationInfo)()

            Using connection = CreateConnection()
                connection.Open()
                Using command = connection.CreateCommand()
                    command.CommandText =
                        "SELECT res.ConfirmationCode, n.Channel, n.Recipient, n.Subject, n.Message, n.Status, n.CreatedAt " &
                        "FROM Notifications n " &
                        "INNER JOIN Reservations res ON res.Id = n.ReservationId " &
                        "ORDER BY datetime(n.CreatedAt) DESC LIMIT 30;"

                    Using reader = command.ExecuteReader()
                        While reader.Read()
                            notifications.Add(New NotificationInfo With {
                                .ConfirmationCode = reader.GetString(0),
                                .Channel = reader.GetString(1),
                                .Recipient = reader.GetString(2),
                                .Subject = reader.GetString(3),
                                .Message = reader.GetString(4),
                                .Status = reader.GetString(5),
                                .CreatedAt = ParseDateTime(reader.GetString(6))
                            })
                        End While
                    End Using
                End Using
            End Using

            Return notifications
        End Function

        Private Function CreateConnection() As SqliteConnection
            Return New SqliteConnection(_connectionString)
        End Function

        Private Shared Function GetSchemaSql() As String
            Return String.Join(Environment.NewLine, New String() {
                "CREATE TABLE IF NOT EXISTS Rooms (Id INTEGER PRIMARY KEY AUTOINCREMENT, RoomNumber TEXT NOT NULL UNIQUE, Type TEXT NOT NULL, Capacity INTEGER NOT NULL, Rate REAL NOT NULL, Amenities TEXT NOT NULL, Status TEXT NOT NULL DEFAULT 'Available');",
                "CREATE TABLE IF NOT EXISTS Guests (Id INTEGER PRIMARY KEY AUTOINCREMENT, FullName TEXT NOT NULL, Email TEXT NOT NULL, Phone TEXT NOT NULL, Address TEXT NOT NULL, CreatedAt TEXT NOT NULL);",
                "CREATE TABLE IF NOT EXISTS Reservations (Id INTEGER PRIMARY KEY AUTOINCREMENT, ConfirmationCode TEXT NOT NULL UNIQUE, RoomId INTEGER NOT NULL, GuestId INTEGER NOT NULL, CheckIn TEXT NOT NULL, CheckOut TEXT NOT NULL, Guests INTEGER NOT NULL, Status TEXT NOT NULL, Notes TEXT NULL, CreatedAt TEXT NOT NULL, FOREIGN KEY (RoomId) REFERENCES Rooms(Id), FOREIGN KEY (GuestId) REFERENCES Guests(Id));",
                "CREATE TABLE IF NOT EXISTS AddOns (Id INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL, Description TEXT NOT NULL, Price REAL NOT NULL);",
                "CREATE TABLE IF NOT EXISTS ReservationAddOns (ReservationId INTEGER NOT NULL, AddOnId INTEGER NOT NULL, Quantity INTEGER NOT NULL, PRIMARY KEY (ReservationId, AddOnId), FOREIGN KEY (ReservationId) REFERENCES Reservations(Id), FOREIGN KEY (AddOnId) REFERENCES AddOns(Id));",
                "CREATE TABLE IF NOT EXISTS Payments (Id INTEGER PRIMARY KEY AUTOINCREMENT, ReservationId INTEGER NOT NULL, Method TEXT NOT NULL, Amount REAL NOT NULL, Status TEXT NOT NULL, PaidAt TEXT NOT NULL, Reference TEXT NOT NULL, FOREIGN KEY (ReservationId) REFERENCES Reservations(Id));",
                "CREATE TABLE IF NOT EXISTS Notifications (Id INTEGER PRIMARY KEY AUTOINCREMENT, ReservationId INTEGER NOT NULL, Channel TEXT NOT NULL, Recipient TEXT NOT NULL, Subject TEXT NOT NULL, Message TEXT NOT NULL, Status TEXT NOT NULL, CreatedAt TEXT NOT NULL, FOREIGN KEY (ReservationId) REFERENCES Reservations(Id));"
            })
        End Function

        Private Shared Sub SeedRooms(connection As SqliteConnection)
            If CountRows(connection, "Rooms") > 0 Then
                Return
            End If

            Dim rooms = New (RoomNumber As String, RoomType As String, Capacity As Integer, Rate As Decimal, Amenities As String)() {
                ("101", "Cozy Standard", 2, 3200D, "Queen bed, garden view, Wi-Fi, hot shower"),
                ("102", "Garden Twin", 3, 3800D, "Twin beds, patio, Wi-Fi, coffee nook"),
                ("201", "Deluxe Queen", 4, 5200D, "Queen bed, lounge chair, smart TV, minibar"),
                ("202", "Sunset Suite", 4, 7200D, "King bed, balcony, bathtub, breakfast set"),
                ("301", "Family Loft", 6, 9800D, "Two bedrooms, kitchenette, dining area, board games"),
                ("302", "Premier Suite", 2, 11800D, "King bed, private balcony, bath ritual kit, late checkout")
            }

            For Each room In rooms
                Execute(connection,
                    "INSERT INTO Rooms (RoomNumber, Type, Capacity, Rate, Amenities, Status) VALUES (@RoomNumber, @Type, @Capacity, @Rate, @Amenities, 'Available');",
                    ("@RoomNumber", room.RoomNumber),
                    ("@Type", room.RoomType),
                    ("@Capacity", room.Capacity),
                    ("@Rate", room.Rate),
                    ("@Amenities", room.Amenities))
            Next
        End Sub

        Private Shared Sub SeedAddOns(connection As SqliteConnection)
            If CountRows(connection, "AddOns") > 0 Then
                Return
            End If

            Dim addOns = New (Name As String, Description As String, Price As Decimal)() {
                ("Breakfast Tray", "Warm breakfast served to the room.", 650D),
                ("Airport Pickup", "Private car pickup for arriving guests.", 1800D),
                ("Spa Welcome Kit", "Bath salts, candle, and herbal tea.", 950D),
                ("Extra Bed", "Foldable bed with linen setup.", 1200D),
                ("Pet Care Pack", "Pet mat, bowl, and welcome treat.", 750D)
            }

            For Each addOn In addOns
                Execute(connection,
                    "INSERT INTO AddOns (Name, Description, Price) VALUES (@Name, @Description, @Price);",
                    ("@Name", addOn.Name),
                    ("@Description", addOn.Description),
                    ("@Price", addOn.Price))
            Next
        End Sub

        Private Shared Function GetRoomForBooking(connection As SqliteConnection, transaction As SqliteTransaction, roomId As Integer) As RoomInfo
            Using command = connection.CreateCommand()
                command.Transaction = transaction
                command.CommandText = "SELECT Id, RoomNumber, Type, Capacity, Rate, Amenities, Status FROM Rooms WHERE Id = @RoomId;"
                command.Parameters.AddWithValue("@RoomId", roomId)

                Using reader = command.ExecuteReader()
                    If Not reader.Read() Then
                        Return Nothing
                    End If

                    Return New RoomInfo With {
                        .Id = reader.GetInt32(0),
                        .RoomNumber = reader.GetString(1),
                        .RoomType = reader.GetString(2),
                        .Capacity = reader.GetInt32(3),
                        .Rate = ToMoney(reader.GetDouble(4)),
                        .Amenities = reader.GetString(5),
                        .Status = reader.GetString(6),
                        .IsAvailable = reader.GetString(6) = "Available"
                    }
                End Using
            End Using
        End Function

        Private Shared Function IsRoomAvailable(connection As SqliteConnection, transaction As SqliteTransaction, roomId As Integer, checkIn As Date, checkOut As Date) As Boolean
            Using command = connection.CreateCommand()
                command.Transaction = transaction
                command.CommandText =
                    "SELECT COUNT(*) FROM Reservations WHERE RoomId = @RoomId " &
                    "AND Status IN ('Reserved', 'Checked In') " &
                    "AND date(CheckIn) < date(@CheckOut) AND date(CheckOut) > date(@CheckIn);"
                command.Parameters.AddWithValue("@RoomId", roomId)
                command.Parameters.AddWithValue("@CheckIn", ToDate(checkIn))
                command.Parameters.AddWithValue("@CheckOut", ToDate(checkOut))
                Return Convert.ToInt32(command.ExecuteScalar(), CultureInfo.InvariantCulture) = 0
            End Using
        End Function

        Private Shared Function GetSelectedAddOns(connection As SqliteConnection, transaction As SqliteTransaction, selectedAddOns As List(Of SelectedAddOn)) As List(Of (Id As Integer, Quantity As Integer, Price As Decimal))
            Dim normalized = selectedAddOns.
                Where(Function(addOn) addOn.Quantity > 0).
                GroupBy(Function(addOn) addOn.AddOnId).
                Select(Function(group) New SelectedAddOn With {.AddOnId = group.Key, .Quantity = group.Sum(Function(addOn) addOn.Quantity)}).
                ToList()

            Dim result As New List(Of (Id As Integer, Quantity As Integer, Price As Decimal))()
            For Each selected In normalized
                Using command = connection.CreateCommand()
                    command.Transaction = transaction
                    command.CommandText = "SELECT Id, Price FROM AddOns WHERE Id = @AddOnId;"
                    command.Parameters.AddWithValue("@AddOnId", selected.AddOnId)

                    Using reader = command.ExecuteReader()
                        If Not reader.Read() Then
                            Throw New ArgumentException("One selected add-on is no longer available.")
                        End If

                        result.Add((reader.GetInt32(0), selected.Quantity, ToMoney(reader.GetDouble(1))))
                    End Using
                End Using
            Next

            Return result
        End Function

        Private Function GetReceiptAddOns(confirmationCode As String) As List(Of AddOnLine)
            Dim addOns As New List(Of AddOnLine)()

            Using connection = CreateConnection()
                connection.Open()
                Using command = connection.CreateCommand()
                    command.CommandText =
                        "SELECT a.Name, ra.Quantity, a.Price FROM ReservationAddOns ra " &
                        "INNER JOIN AddOns a ON a.Id = ra.AddOnId " &
                        "INNER JOIN Reservations res ON res.Id = ra.ReservationId " &
                        "WHERE res.ConfirmationCode = @ConfirmationCode ORDER BY a.Name;"
                    command.Parameters.AddWithValue("@ConfirmationCode", confirmationCode)

                    Using reader = command.ExecuteReader()
                        While reader.Read()
                            Dim quantity = reader.GetInt32(1)
                            Dim unitPrice = ToMoney(reader.GetDouble(2))
                            addOns.Add(New AddOnLine With {
                                .Name = reader.GetString(0),
                                .Quantity = quantity,
                                .UnitPrice = unitPrice,
                                .Total = unitPrice * quantity
                            })
                        End While
                    End Using
                End Using
            End Using

            Return addOns
        End Function

        Private Shared Sub QueueNotification(connection As SqliteConnection, transaction As SqliteTransaction, reservationId As Long, channel As String, recipient As String, subject As String, message As String, createdAt As Date)
            Execute(connection, transaction,
                "INSERT INTO Notifications (ReservationId, Channel, Recipient, Subject, Message, Status, CreatedAt) " &
                "VALUES (@ReservationId, @Channel, @Recipient, @Subject, @Message, 'Queued locally', @CreatedAt);",
                ("@ReservationId", reservationId),
                ("@Channel", channel),
                ("@Recipient", recipient),
                ("@Subject", subject),
                ("@Message", $"{message} Email/SMS delivery is simulated in this local VB project."),
                ("@CreatedAt", ToDateTime(createdAt)))
        End Sub

        Private Shared Function GenerateConfirmationCode(connection As SqliteConnection, transaction As SqliteTransaction) As String
            For attempt = 1 To 10
                Dim code = $"HR-{DateTime.UtcNow:yyMMdd}-{Random.Shared.Next(1000, 9999)}"
                Using command = connection.CreateCommand()
                    command.Transaction = transaction
                    command.CommandText = "SELECT COUNT(*) FROM Reservations WHERE ConfirmationCode = @Code;"
                    command.Parameters.AddWithValue("@Code", code)
                    If Convert.ToInt32(command.ExecuteScalar(), CultureInfo.InvariantCulture) = 0 Then
                        Return code
                    End If
                End Using
            Next

            Throw New InvalidOperationException("Could not generate a reservation code. Please try again.")
        End Function

        Private Shared Sub ValidateReservation(request As ReservationInput)
            If request.CheckOut.Date <= request.CheckIn.Date Then
                Throw New ArgumentException("Check-out must be after check-in.")
            End If

            If request.Guests <= 0 Then
                Throw New ArgumentException("Please enter at least one guest.")
            End If

            If String.IsNullOrWhiteSpace(request.GuestName) OrElse
               String.IsNullOrWhiteSpace(request.Email) OrElse
               String.IsNullOrWhiteSpace(request.Phone) Then
                Throw New ArgumentException("Guest name, email, and phone are required.")
            End If

            If String.IsNullOrWhiteSpace(request.PaymentMethod) Then
                Throw New ArgumentException("Please choose a payment method.")
            End If
        End Sub

        Private Shared Function BuildPaymentReference(reference As String) As String
            If Not String.IsNullOrWhiteSpace(reference) Then
                Return reference.Trim()
            End If

            Return $"LOCAL-{DateTime.UtcNow:yyyyMMddHHmmss}"
        End Function

        Private Shared Function CountRows(connection As SqliteConnection, tableName As String) As Integer
            Using command = connection.CreateCommand()
                command.CommandText = $"SELECT COUNT(*) FROM {tableName};"
                Return Convert.ToInt32(command.ExecuteScalar(), CultureInfo.InvariantCulture)
            End Using
        End Function

        Private Shared Sub Execute(connection As SqliteConnection, sql As String, ParamArray parameters As (Name As String, Value As Object)())
            Using command = connection.CreateCommand()
                command.CommandText = sql
                AddParameters(command, parameters)
                command.ExecuteNonQuery()
            End Using
        End Sub

        Private Shared Sub Execute(connection As SqliteConnection, transaction As SqliteTransaction, sql As String, ParamArray parameters As (Name As String, Value As Object)())
            Using command = connection.CreateCommand()
                command.Transaction = transaction
                command.CommandText = sql
                AddParameters(command, parameters)
                command.ExecuteNonQuery()
            End Using
        End Sub

        Private Shared Function InsertScalar(connection As SqliteConnection, transaction As SqliteTransaction, sql As String, ParamArray parameters As (Name As String, Value As Object)()) As Long
            Using command = connection.CreateCommand()
                command.Transaction = transaction
                command.CommandText = sql
                AddParameters(command, parameters)
                Return Convert.ToInt64(command.ExecuteScalar(), CultureInfo.InvariantCulture)
            End Using
        End Function

        Private Shared Sub AddParameters(command As SqliteCommand, ParamArray parameters As (Name As String, Value As Object)())
            For Each parameter In parameters
                command.Parameters.AddWithValue(parameter.Name, If(parameter.Value, DBNull.Value))
            Next
        End Sub

        Private Shared Function ToDate(value As Date) As String
            Return value.Date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)
        End Function

        Private Shared Function ToDateTime(value As Date) As String
            Return value.ToString("O", CultureInfo.InvariantCulture)
        End Function

        Private Shared Function ParseDate(value As String) As Date
            Return DateTime.ParseExact(value, "yyyy-MM-dd", CultureInfo.InvariantCulture)
        End Function

        Private Shared Function ParseDateTime(value As String) As Date
            Return DateTime.Parse(value, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind)
        End Function

        Private Shared Function ToMoney(value As Double) As Decimal
            Return Math.Round(Convert.ToDecimal(value, CultureInfo.InvariantCulture), 2)
        End Function
    End Class
End Namespace
