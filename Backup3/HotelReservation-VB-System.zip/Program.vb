Imports System
Imports System.Globalization
Imports System.IO
Imports System.Windows.Forms

Namespace HotelReservation
    Friend Module Program
        <STAThread>
        Public Sub Main()
            CultureInfo.DefaultThreadCurrentCulture = New CultureInfo("en-PH")
            CultureInfo.DefaultThreadCurrentUICulture = New CultureInfo("en-PH")
            Application.EnableVisualStyles()
            Application.SetCompatibleTextRenderingDefault(False)

            Dim databasePath = Path.Combine(AppContext.BaseDirectory, "hotel_reservation.db")
            Dim repository = New HotelRepository(databasePath)
            repository.Initialize()

            Application.Run(New MainForm(repository))
        End Sub
    End Module
End Namespace
